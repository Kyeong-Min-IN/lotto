function getRandomLotto() {
    let numbers = new Set();
    while (numbers.size < 6) {
        numbers.add(Math.floor(Math.random() * 45) + 1);
    }
    return [...numbers].sort((a, b) => a - b);
}

function getUserNumbers() {
    let inputs = [
        document.getElementById("num1").value,
        document.getElementById("num2").value,
        document.getElementById("num3").value,
        document.getElementById("num4").value,
        document.getElementById("num5").value,
        document.getElementById("num6").value
    ];
    let userNumbers = inputs.map(num => parseInt(num)).filter(num => num >= 1 && num <= 45);

    if (userNumbers.length !== 6 || new Set(userNumbers).size !== 6) {
        alert("⚠️ 1~45 사이의 중복되지 않은 6개의 숫자를 입력하세요!");
        return null;
    }

    return userNumbers.sort((a, b) => a - b);
}

function startSimulation() {
    let userNumbers = getUserNumbers();
    if (!userNumbers) return;

    document.getElementById("userNumbers").textContent = userNumbers.join(", ");

    let attempts = 0;
    let winningNumbers;
    let simulationLog = "";

    do {
        winningNumbers = getRandomLotto();
        attempts++;
        if (attempts % 100000 === 0) { // 10만 회마다 로그 업데이트
            simulationLog = `🔥 ${attempts.toLocaleString()}회 시도 중...\n`;
            document.getElementById("simulationResult").textContent = simulationLog;
        }
    } while (!arraysEqual(userNumbers, winningNumbers));

    document.getElementById("finalResult").innerHTML = `
        🎉 <strong>${winningNumbers.join(", ")}</strong> (당첨 번호) <br>
        🎰 <strong>${attempts.toLocaleString()}</strong>번 만에 당첨되었습니다!`;
}

function arraysEqual(a, b) {
    return JSON.stringify(a) === JSON.stringify(b);
}